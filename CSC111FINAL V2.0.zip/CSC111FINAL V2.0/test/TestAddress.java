
//Test the Address Class 




/**
 *
 * @author CHARITH
 */
import EL_FUEGO.Address;

public class TestAddress {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
        Address address = new Address("Maradana" , "Colombo");
        
        System.out.println(address);
           
    }
    
}

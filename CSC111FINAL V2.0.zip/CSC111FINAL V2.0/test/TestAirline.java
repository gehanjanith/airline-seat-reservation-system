
//Test the Airline Class



/**
 *
 * @author CHARITH
 */
import EL_FUEGO.Airline;

public class TestAirline {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Airline airline = new Airline("MH" , "AIR"); 
        
        System.out.println(airline);
    }
    
}

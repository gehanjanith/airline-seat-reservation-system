//Test the Airport class



/**
 *
 * @author CHARITH
 */
import EL_FUEGO.Airport;

public class TestAirport {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Test the Airport Constructor
        
        Airport air = new Airport("CCU","Kolkata","India");
        
        System.out.println(air);
    }
    
}
